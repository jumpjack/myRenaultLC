<?php
$session['Date Gigya JWT']									=	'0000';             // 0: Date Gigya JWT Token request (md)
$session['Gigya JWT Token']									=	'';                 // 1: Gigya JWT Token
$session['Renault account id']								=	'';                 // 2: Renault account id
$session['MD5 hash']										=	'';                 // 3: MD5 hash of the last data retrieval
$session['Timestamp of the last data']						=	'202001010000';     // 4: Timestamp of the last data retrieval (YmdHi)
$session['Action done when reaching battery level (Y/N)']	=	'N';                // 5: Action done when reaching battery level (Y/N)
$session['Car is charging (Y/N)']							=	'N';                // 6: Car is charging (Y/N)
$session['Mileage']											=	'please wait...';   // 7: Mileage
$session['Date status update']								=	'please wait...';   // 8: Date status update
$session['Time status update']								=	'please wait...';   // 9: Time status update
$session['Charging status']									=	'please wait...';   // 10: Charging status
$session['Cable status']									=	'please wait...';   // 11: Cable status
$session['Battery level']									=	'please wait...';   // 12: Battery level
$session['Battery level-temp']								=	'please wait...';   // 13:Battery levelrature (Ph1) / battery capacity (Ph2)
$session['Range in km']										=	'please wait...';   // 14: Range in km
$session['Charging time']									=	'please wait...';   // 15: Charging time
$session['Charging effect']									=	'please wait...';   // 16: Charging effect
$session['Outside temperature (Ph1) / GPS']					=	'please wait...';   // 17: Outside temperature (Ph1) / GPS-Latitude (Ph2)
$session['GPS-Long']										=	'please wait...';   // 18: GPS-Longitude (Ph2)
$session['GPS time/date']									=	'please wait...';   // 19: GPS: GPS time (Ph2; H:i) date (Ph2; d.m.Y)
$session['GPS time']										=	'please wait...';   // 20: GPS time (Ph2; H:i)
$session['Setting battery level for mail function']			=	'80';               // 21: Setting battery level for mail function
$session['Outside temp']									=	'please wait...';   // 22: Outside temperature (Ph2; openweathermap API)
$session['Weather']											=	'please wait...';   // 23: Weather condition (Ph2; openweathermap API)
$session['Chargemode']										=	'please wait...';   // 24: Chargemode
?>